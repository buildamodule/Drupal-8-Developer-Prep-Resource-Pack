<?php

/**
 * @file
 * Definition of Drupal\Core\Database\Driver\sqlite\Update
 */

namespace Drupal\Core\Database\Driver\sqlite;

use Drupal\Core\Database\Query\Update as QueryUpdate;

class Update extends QueryUpdate { }
